# README #

### What's the Awesome Shield Library for? ###

* An Arduino library that works with the Awesome Shield prototype hardware V0.4

### How do I get it set up? ###

* download this library by clicking "Download Zip" on the right-hand side of this page
* open the Arduino IDE
* select "Sketch > Import Library... > Add Library... "
* select folder called "Awesome" in the file browser
* click "import"

### Questions? ###

* Contact Chris Palmer (username: cwjpalmer, email: chris [at] awesomeshield [dot] com)
